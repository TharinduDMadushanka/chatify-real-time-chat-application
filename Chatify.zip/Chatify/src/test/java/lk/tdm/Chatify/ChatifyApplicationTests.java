package lk.tdm.Chatify;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatifyApplicationTests {

	@Test
	void contextLoads() {
	}

}
