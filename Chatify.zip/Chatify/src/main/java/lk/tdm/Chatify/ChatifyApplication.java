package lk.tdm.Chatify;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatifyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChatifyApplication.class, args);
	}

}
